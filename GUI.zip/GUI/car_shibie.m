function varargout = car_shibie(varargin)
% CAR_SHIBIE MATLAB code for car_shibie.fig
%      CAR_SHIBIE, by itself, creates a new CAR_SHIBIE or raises the existing
%      singleton*.
%
%      H = CAR_SHIBIE returns the handle to a new CAR_SHIBIE or the handle to
%      the existing singleton*.
%
%      CAR_SHIBIE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CAR_SHIBIE.M with the given input arguments.
%
%      CAR_SHIBIE('Property','Value',...) creates a new CAR_SHIBIE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before car_shibie_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to car_shibie_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help car_shibie

% Last Modified by GUIDE v2.5 27-Apr-2020 19:38:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @car_shibie_OpeningFcn, ...
                   'gui_OutputFcn',  @car_shibie_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before car_shibie is made visible.
function car_shibie_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to car_shibie (see VARARGIN)

% Choose default command line output for car_shibie
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes car_shibie wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = car_shibie_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile({'*.jpg';'*.bmp'}, 'File Selector');
if isequal(filename,0)
   msgbox('û��ͼƬ')
else
    pathfile=fullfile(pathname,filename);
    I=imread(pathfile);
     msgbox('����ͼƬ�ɹ�')
     pause(2);
end
handles.I=I;
guidata(hObject, handles);
axes(handles.axes1);
imshow(I);title('ԭͼ');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I = handles.I;
[PY2,PY1,PX2,PX1]=chepai_dingwei(I);
%===============������������������У��======================
global jiaodu;
[PY2,PY1,PX2,PX1,threshold]=jiaozheng(PY2,PY1,PX2,PX1);
jiaodu = threshold;
%==============����ͼƬ=============================
I_new=I(PY1:PY2,PX1:PX2,:);
%==============�����ø�ʴ�����ɫ������=============
bw=I_new;
bw=rgb2gray(bw);
axes(handles.axes2);
imwrite(bw,'����.jpg');
imshow(bw);title('����');

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%================��бУ��======================
bw = imread('����.jpg');
global qingxiejiao
qingxiejiao=rando_bianhuan(bw)%��ȡ��б�Ƕ�
bw=imrotate(bw,qingxiejiao,'bilinear','crop');%figure,imshow(bw);title('��бУ��');%ȡֵΪ��ֵ������ת
%==============================================
bw=im2bw(bw,graythresh(bw));%figure,imshow(bw);
bw=bwmorph(bw,'hbreak',inf);%figure,imshow(bw);
bw=bwmorph(bw,'spur',inf);%figure,imshow(bw);title('����֮ǰ');
bw=bwmorph(bw,'open',5);%figure,imshow(bw);title('�պ�����');
global jiaodu;
threshold = jiaodu;
bw = bwareaopen(bw, threshold);%figure,imshow(bw);title('����');
%==========================================================
bw=~bw;%figure,imshow(bw);title('������ɫ'); 
%=============��ͼ���һ���ü�����֤�߿���������===========
bw=touying(bw);%figure;imshow(bw);title('Y������');
bw=~bw;
bw = bwareaopen(bw, threshold);
bw=~bw;%figure,imshow(bw);title('���β���');
axes(handles.axes3);
imshow(bw);title('ԭͼ');
global cpfgq;
cpfgq = bw;


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global cpfgq;
bw = cpfgq;
[y,x]=size(bw);%�Գ������¸�ֵ
% %=================���ַָ�=================================
global qingxiejiao
 fenge=shuzifenge(bw,qingxiejiao)
 [m,k]=size(fenge);
% %=================��ʾ�ָ�ͼ����========================= 
% figure;
% for s=1:2:k-1
%     subplot(1,k/2,(s+1)/2);imshow(~bw( 1:y,fenge(s):fenge(s+1)));
% end
%================ ������ͼƬ��λ===============
han_zi  =~bw( 1:y,fenge(1):fenge(2));
zi_mu   =~bw( 1:y,fenge(3):fenge(4));
zm_sz_1 =~bw( 1:y,fenge(5):fenge(6));
zm_sz_2 =~bw( 1:y,fenge(7):fenge(8));  
shuzi_1 =~bw( 1:y,fenge(9):fenge(10)); 
shuzi_2 =~bw( 1:y,fenge(11):fenge(12)); 
shuzi_3 =~bw( 1:y,fenge(13):fenge(14)); 
%==========================ʶ��====================================
%======================���������ݶ���==============================
global xiuzhenghanzi;
xiuzhenghanzi =   imresize(han_zi, [110 55],'bilinear');
axes(handles.axes4);
imshow(xiuzhenghanzi);title('���Ƶ�һλ');
global xiuzhengzimu;
xiuzhengzimu  =   imresize(zi_mu,  [110 55],'bilinear');
axes(handles.axes8);
imshow(xiuzhengzimu);title('���Ƶڶ�λ');
global xiuzhengzm_sz_1;
xiuzhengzm_sz_1=  imresize(zm_sz_1,[110 55],'bilinear');
axes(handles.axes9);
imshow(xiuzhengzm_sz_1);title('���Ƶ���λ');
global xiuzhengzm_sz_2;
xiuzhengzm_sz_2 = imresize(zm_sz_2,[110 55],'bilinear');
axes(handles.axes10);
imshow(xiuzhengzm_sz_2);title('���Ƶ���λ');
global xiuzhengshuzi_1;
xiuzhengshuzi_1 = imresize(shuzi_1,[110 55],'bilinear');
axes(handles.axes11);
imshow(xiuzhengshuzi_1);title('���Ƶ���λ');
global xiuzhengshuzi_2;
xiuzhengshuzi_2 = imresize(shuzi_2,[110 55],'bilinear');
axes(handles.axes12);
imshow(xiuzhengshuzi_2);title('���Ƶ���λ');
global xiuzhengshuzi_3;
xiuzhengshuzi_3 = imresize(shuzi_3,[110 55],'bilinear');
axes(handles.axes13);
imshow(xiuzhengshuzi_3);title('���Ƶ���λ');


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load param_char.mat param_char;
load param_num.mat param_num;
global xiuzhenghanzi;
global xiuzhengzimu;
global xiuzhengzm_sz_1;
global xiuzhengzm_sz_2;
global xiuzhengshuzi_1;
global xiuzhengshuzi_2;
global xiuzhengshuzi_3;
resultc = recchar(xiuzhenghanzi, param_char);
chepai2= recplate(xiuzhengzimu, param_num);
chepai3= recplate(xiuzhengzm_sz_1, param_num);
chepai4= recplate(xiuzhengzm_sz_2, param_num);
chepai5= recplate(xiuzhengshuzi_1, param_num);
chepai6= recplate(xiuzhengshuzi_2, param_num);
chepai7= recplate(xiuzhengshuzi_3, param_num);
global shibiejieguo
shibiejieguo = strcat(resultc,chepai2,chepai3, chepai4,chepai5, chepai6,chepai7);
set(handles.edit1,'string',num2str(shibiejieguo));



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
